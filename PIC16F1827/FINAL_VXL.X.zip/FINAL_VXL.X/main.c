#define IRL PORTAbits.RA0  //Cam bien trai
#define IRR PORTAbits.RA7  //Cam bien phai
#define IRC PORTAbits.RA2  //Cam bien giua
#define LINE 1
#define NO_LINE 0
#define IN1_3   LATBbits.LATB6
#define IN2_4   LATAbits.LATA1
#define echo    PORTBbits.RB5
#define trig    LATBbits.LATB4
//CCP3 CCP4

#include "mcc_generated_files/mcc.h"
char str[50];
unsigned int mode_manual = 0 ,mode_auto = 1, K = 1;           
int Saved_Level,PWM_Left,PWM_Right,Level_Right,Level_Left;
int Error,P = 0,I = 0,D = 0,Kp = 1,Ki = 1,Kd = 1,Previous_Error = 0;
unsigned int distance_us, Vat_can = 0 ;
float  distance_cm;
void Stop()
{
    IN1_3 = 0;
    IN2_4 = 0;
}
void Go_Ahead()
{
    IN1_3 = 0;  
    IN2_4 = 1;
}
void Go_Back()
{
    IN1_3 = 1;  
    IN2_4 = 0;
}


void main(void)
{//void   
    
    while(1)
    {    
    Level_Right = Level_Left = 5;
    Saved_Level = 1;
    SYSTEM_Initialize();
    while (mode_manual == 1)
    {//while
       PWM_Left =Level_Left*100+99;
       PWM_Right =Level_Right*100+99;
       PWM3_LoadDutyValue(PWM_Left);
       PWM4_LoadDutyValue(PWM_Right);
        for (int i=0;i<10;i++){ 
            while ((EUSART_is_rx_ready()== 0));
            str[i]=EUSART_Read();
            if(str[i]=='B') { 
                if (Level_Right > Level_Left ) {Level_Left = Level_Right;}
                else {Level_Right = Level_Left;}
                Saved_Level = Level_Right;
                Go_Back(); 
                __delay_ms(20);
            }
            if (str[i]=='F') {  
                if (Level_Right > Level_Left ) {Level_Left = Level_Right;}
                else {Level_Right = Level_Left;}
                Saved_Level = Level_Right;
                Go_Ahead(); 
                __delay_ms(20);
            }
            if (str[i]=='0') Saved_Level = Level_Left = Level_Right = 0;
            if (str[i]=='1') Saved_Level = Level_Left = Level_Right = 1;
            if (str[i]=='2') Saved_Level = Level_Left = Level_Right = 2;
            if (str[i]=='3') Saved_Level = Level_Left = Level_Right = 3;
            if (str[i]=='4') Saved_Level = Level_Left = Level_Right = 4;
            if (str[i]=='5') Saved_Level = Level_Left = Level_Right = 5;
            if (str[i]=='6') Saved_Level = Level_Left = Level_Right = 6;
            if (str[i]=='7') Saved_Level = Level_Left = Level_Right = 7; 
            if (str[i]=='8') Saved_Level = Level_Left = Level_Right = 8; 
            if (str[i]=='9') Saved_Level = Level_Left = Level_Right = 9; 
            if (str[i]=='q') Saved_Level = Level_Left = Level_Right = 10; 
            
            if (str[i]=='L') {
                Level_Left = 0;
                Level_Right = Saved_Level;
                __delay_ms(1);
                Go_Ahead(); 
                __delay_ms(20);
            }
            if (str[i]=='R') {
                Level_Right = 0;
                Level_Left = Saved_Level;
                __delay_ms(1);
                Go_Ahead(); 
                __delay_ms(20);
            }
            
            if (str[i]=='G') {
                Level_Right = Saved_Level;               
                Level_Left = Saved_Level-2 ;
                if (Level_Left < 0) Level_Left = 0; 
                Go_Ahead(); 
                __delay_ms(20);
            }
            if (str[i]=='I') {
                Level_Right = 0;
                Level_Left = Saved_Level;               
                Level_Right = Saved_Level-2 ;
                if (Level_Right < 0) Level_Right = 0; 
                Go_Ahead(); 
                __delay_ms(20);
            }
            
            else if (str[i]=='V') {
                mode_manual = 0;
                mode_auto = 1;
            }
            else  {Stop();}
                
            
        }         
    }
   
    PWM3_LoadDutyValue(600); PWM4_LoadDutyValue(600);
            __delay_us(1);
            Go_Ahead(); 
            __delay_ms(500);
            PWM3_LoadDutyValue(0); PWM4_LoadDutyValue(0);
            __delay_ms(50);
    
    distance_cm = 4;
    LATBbits.LATB3 = 0;
    K = 1;
    
    while(mode_auto == 1) 
    {
        
        
        if ( distance_cm >= 3) {
        
        trig = 1;
        __delay_ms(1);
        trig = 0;
        while (echo == 0);
        TMR0 = 0;
        while (echo == 1);
        distance_us = TMR0*32*4;
        distance_cm = (float)distance_us/58;            
        if ((IRL == 0)&&(IRC == 0)&&(IRR == 1)) Error = +1;
        else if ((IRL == 0)&&(IRC == 1)&&(IRR == 0)) Error = 0;
        else if ((IRL == 1)&&(IRC == 0)&&(IRR == 0)) Error = -1; 
        else if ((IRL == 0)&&(IRC == 0)&&(IRR == 0)) 
        { 
            if (Previous_Error == -1) {Error = -2;}
            if (Previous_Error == +1) {Error = +2;}
            
        }
        
        if (K==1)
        {
            if ((IRL == 1)&&(IRC == 1)&&(IRR == 0)) 
        {
            PWM3_LoadDutyValue(600);
            PWM4_LoadDutyValue(0);
            Go_Ahead(); 
            __delay_ms(1100);
            PWM3_LoadDutyValue(0);
            PWM4_LoadDutyValue(0);
                       
        }
        
        if ((IRL == 0)&&(IRC == 1)&&(IRR == 1)) 
        {
            PWM3_LoadDutyValue(600);
            PWM4_LoadDutyValue(0);
            Go_Ahead(); 
            __delay_ms(1100);
            PWM3_LoadDutyValue(0);
            PWM4_LoadDutyValue(0);
                       
        }
        
        if ((IRL == 1)&&(IRC == 0)&&(IRR == 1)) 
        {
            PWM3_LoadDutyValue(600);
            PWM4_LoadDutyValue(0);
            Go_Ahead(); 
            __delay_ms(1100);
            PWM3_LoadDutyValue(0);
            PWM4_LoadDutyValue(0);
                       
        }
        
            K = 0;
        }
         if ((IRL == 1)&&(IRC == 1)&&(IRR == 1)) 
        {
            PWM3_LoadDutyValue(600);
            PWM4_LoadDutyValue(0);
            Go_Ahead(); 
            __delay_ms(1100);
            PWM3_LoadDutyValue(0);
            PWM4_LoadDutyValue(0);
                       
        }
                
        if (Error == -2) 
        {
            PWM3_LoadDutyValue(0);
            PWM4_LoadDutyValue(885);
            __delay_us(1);
            Go_Ahead(); 
            __delay_us(5500);
            PWM3_LoadDutyValue(0); PWM4_LoadDutyValue(0);
            __delay_ms(1);
            Previous_Error = -1;
        }    
            
        if (Error == +2) 
        {
             PWM4_LoadDutyValue(0);
            PWM3_LoadDutyValue(885);
            __delay_us(1);
            Go_Ahead(); 
            __delay_us(5500);
            PWM3_LoadDutyValue(0);
            PWM4_LoadDutyValue(0);
            __delay_ms(1);
            Previous_Error = +1;
        }
        if (Error == -1) 
        {
            PWM3_LoadDutyValue(0);
            PWM4_LoadDutyValue(885);
            __delay_us(1);
            Go_Ahead(); 
            __delay_us(5500);
            PWM3_LoadDutyValue(0);
            PWM4_LoadDutyValue(0);
            __delay_us(1);
            Previous_Error = Error;
        }
            if (Error == +1) 
        {
            PWM4_LoadDutyValue(0);
            PWM3_LoadDutyValue(885);
            __delay_us(1);
            Go_Ahead(); 
            __delay_us(5500);
            PWM3_LoadDutyValue(0); PWM4_LoadDutyValue(0);
            __delay_ms(1);
            Previous_Error = Error;
        }

        else 
        {
            PWM3_LoadDutyValue(780); PWM4_LoadDutyValue(780);
            __delay_us(1);
            Go_Ahead(); 
            __delay_ms(5);
            PWM3_LoadDutyValue(0); PWM4_LoadDutyValue(0);
            __delay_ms(1);
            Previous_Error = Error;
        }
        }
        else {mode_auto = 0;mode_manual = 1;}
    }
    }  
}
